<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="row">
            <div class="col-md-3">
                <a href="<?php echo e(URL::previous()); ?>" role="button" class="btn btn-primary w-100">Back</a>
            </div>
            <div class="col-md-3">
                <a href="<?php echo e(url('product-create')); ?>" role="button" class="btn btn-light shadow-sm w-100">Create new Product</a>
            </div>
        </div>
        <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title">Add Category</h4>
            <p class="card-category">Add category activity</p>
          </div>
          <div class="card-body pt-5">
            <form action='<?php echo e(url("category-update/$category->id")); ?>' method="POST">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                  <label for="name">Name</label>
                  <input type="text" value="<?php echo e($category->name); ?>" name="name" id="name" class="form-control" placeholder="Enter Product Name...">
                </div>
                <div class="text-right">
                    <button class="btn btn-primary px-5">Save</button>
                </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'products', 'titlePage' => __('Products List')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tugas\Other\Jaden\resources\views/pages/categories/category_edit.blade.php ENDPATH**/ ?>