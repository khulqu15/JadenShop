<?php $__env->startSection('content'); ?>
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-12">
        <div class="row">
            <div class="col-md-3 offset-md-3">
                <a href="<?php echo e(url('/home')); ?>" role="button" class="btn btn-primary w-100">Add new Product</a>
            </div>
            <div class="col-md-3">
                <a href="<?php echo e(url('/home')); ?>" role="button" class="btn btn-light shadow-sm w-100">Categories</a>
            </div>
        </div>
        <div class="card">
          <div class="card-header card-header-primary">
            <h4 class="card-title">Product Table</h4>
            <p class="card-category">Manage products activity</p>
          </div>
          <div class="card-body">
            <div class="table-responsive">
              <table class="table">
                <thead class=" text-primary">
                  <th>Picture</th>
                  <th>Name</th>
                  <th>Price</th>
                  <th>Stock</th>
                  <th>Action</th>
                </thead>
                <tbody>
                  <tr>
                    <td><img src="<?php echo e(asset('material/img/favicon.png')); ?>" alt="product" width="60px"></td>
                    <td>Dummy Jaden shop</td>
                    <td class="text-primary">Rp 200000</td>
                    <td class="text-info">10</td>
                    <td>
                        <a href="<?php echo e(url('/home')); ?>" role="button" class="btn btn-sm btn-success">Edit</a>
                        <a href="<?php echo e(url('/home')); ?>" role="button" class="btn btn-sm btn-danger">Hapus</a>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', ['activePage' => 'table', 'titlePage' => __('Table List')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Tugas\Other\Jaden\resources\views/pages/product_list.blade.php ENDPATH**/ ?>