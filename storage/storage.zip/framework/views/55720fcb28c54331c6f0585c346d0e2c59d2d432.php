<footer class="footer">
  <div class="container-fluid">
    <nav class="float-left">
      <ul>
        <li>
          <a href="https://www.instagram.com/sidescript_dev/">
              <?php echo e(__('Developer')); ?>

          </a>
        </li>
        <li>
          <a href="https://www.instagram.com/achmadzainudin07/">
              <?php echo e(__('Client')); ?>

          </a>
        </li>
      </ul>
    </nav>
    <div class="copyright float-right">
      &copy;
      <script>
        document.write(new Date().getFullYear())
      </script>, made with <i class="material-icons">favorite</i> by
      <a href="https://www.instagram.com/sidescript_dev/" target="_blank">Sidescript</a> and <a href="https://www.instagram.com/achmadzainudin07/" target="_blank">A Zainuddin</a> for a better web.
    </div>
  </div>
</footer>
<?php /**PATH C:\xampp\htdocs\Tugas\Other\Jaden\resources\views/layouts/footers/auth.blade.php ENDPATH**/ ?>